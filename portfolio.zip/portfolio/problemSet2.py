#Factorial!
#takes input and get the factorial of it
def Factorial(num):

    count = 1
  # i goes from 1 to the num and by doing so, we can get a factorial of the num
    for i in range(1,num+1):
        count = count * i
      
    print ("The factorial of" , num, " is" )
    print (count)

#Double It!
    #takes user input and get the double of it
def DoubleIt():
    string=input("Please enter a phrase that you would like to 'double':  ")
    #empty output fot now 
    output=" "
    # i will go one by one of input
    for i in string:
        #make a new output with double input
        output=output+i+i
    

    print(output)
    

#Camel Case! 
def CamelCase():
    answer=input("please enter a filename:  ")

    answer=answer.title()
    #using replace to remove spaces, and upper case of each new word, except first one
    answer=answer.replace(" ","")
    answer=answer.replace(" ","")[0].lower()+answer.replace(" ","")[1:]
#using relace to change all / to -
    print("your filename should be", answer.replace("/","-"))


def P2main():
    print("start problem set #2")
    Factorial(9)
    Factorial(17)
    Factorial(25)
    DoubleIt()
    DoubleIt()
    DoubleIt()
    CamelCase()
    CamelCase()
    print("end")
    



    
