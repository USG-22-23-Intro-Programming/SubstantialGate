


    
#Greeting!
   # this will ask you an user input and use that input as a part of output
def greeting():
    answer=input("Please enter your name:  ")
    print("Nice to meet you! "+answer+", I'm Jaein, have a good day!")

#IsMultiple!
 # this will help you to find out if two number is multiple
 # it's not taking user input 
def ismultiple(x,y):
# using mod, if mod=0, it's multiple
# % is mod
    if (x%y==0):
        print(int(x), " is a multiple of ", int(y))
    else:
        print(int(x), " is not a multiple of " , int(y))

        

def palindrome():
    # this will take user input and use as part as a outcome
    s=input("please enter a potential palindrome: ")
    # ::-1 is reverse s, so it's checking if s=reverse s
    if s[::-1]==s:
        print("Fantasic!", s , "is a palindrome")
    else:
        print("Unfortuately,", s , "is not a palindrome")
    # when you do a[::-1], it starts from the end towards, So it reverses a.
    
        

#creating method
def P1main():
    greeting()
    ismultiple(20,3)
    answer=palindrome()
    print(answer)



        
