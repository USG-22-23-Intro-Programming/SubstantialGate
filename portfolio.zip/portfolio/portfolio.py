# Importing all 5 files that will be on my portfoilo
from SharkSimulator import *
from imageEditor import *
from problemSet import *
from problemSet2 import *
from problemSet3 import *

def main():
     
     win = GraphWin("Portfolio-Jaein Han", 850, 650)
     win.setBackground("floralwhite")
# drawing button for quit, 5 file and explanation for those file by using text
     Q = Button(win, Point(100, 550), Point(750, 580), "lemonchiffon2", "QUIT")
#for problem set 1     
     P1= Button(win, Point(100, 50), Point(200, 100), "pink", "Problem Set 1")
     P1info= Text(Point(520, 50), 'Problem Set1 contains Greeting, Is Mulitpe and Palindrome. Greeting takes user input and prints greeting for them.')
     P1info2= Text(Point(520,70),'Is Multiple takes two integers as parameter and prints out whether the first number is a multiple of the second number.') 
     P1info3= Text(Point(520, 90), 'Palindrome takes user input and prints whether it is palindrome or not.')
     P1info4= Text(Point(520, 110), 'Problem set 1 is to build basic skills for python and to know how to use user input')
     P1info.draw(win)
     P1info2.draw(win)
     P1info3.draw(win)
     P1info4.draw(win)
     P2= Button(win, Point(100, 150), Point(200, 200), "lightgoldenrod1", "Problem Set 2")
#for problem set 2    
     P2info= Text(Point(520, 150), 'Problem Set2 contains Factorial, Double it and camel Case. Factorials takes one integer and prints factorial for that integer.')
     P2info2= Text(Point(520,170),'Double it takes user input and output where all of the characters happen twice.') 
     P2info3= Text(Point(520, 190), 'Camel Case takes user input(file name) and gives the better filename with no space, camel case and replace / to -')
     P2info4= Text(Point(520, 210), 'Problem set 2 is to build better understanding in math and methods')
     P2info.draw(win)
     P2info2.draw(win)
     P2info3.draw(win)
     P2info4.draw(win)
#for problem set 3     
     P3= Button(win, Point(100, 250), Point(200, 300), "palegreen", "Problem Set 3")
     P3info= Text(Point(520, 250), 'Problem Set3 contains Currency Converter and Grocery List.')
     P3info2= Text(Point(520,270),'Currency Converter convert amount of money you have into new currency that you choose between the choices') 
     P3info3= Text(Point(520, 290),  'Grocery list has dictionary of food and price, and gives you total price of things that was in the list')
     P3info4= Text(Point(520, 310), 'Problem Set3 helps us with harder math and using list')
     P3info.draw(win)
     P3info2.draw(win)
     P3info3.draw(win)
     P3info4.draw(win)
#for image editor    
     Image= Button(win, Point(100, 350), Point(200, 400), "paleturquoise1", "Image Editor")
     Imageinfo= Text(Point(520, 340), 'By using Image Editor, you can darken, lighten, use gray scale, contrast the image.')
     Imageinfo2= Text(Point(520,360),'Image editor is focused in creating graphical object in window and manage GUI.') 
     Imageinfo3= Text(Point(520, 380), 'This has multiple buttons including quit and when you push,')
     Imageinfo4= Text(Point(520, 400), 'every button will have different filters, you get based on what button you pushed')
     Imageinfo.draw(win)
     Imageinfo2.draw(win)
     Imageinfo3.draw(win)
     Imageinfo4.draw(win)
#for shark simulator     
     Shark= Button(win, Point(100, 450), Point(200, 500), "plum", "Shark simulator")
     Sharkinfo= Text(Point(520, 440), 'Shark simulator simulates a shark eating three fish,')
     Sharkinfo2= Text(Point(520,460),'when fish is running away from shark and shark follows the closest one.') 
     Sharkinfo3= Text(Point(520, 480), 'This helps us with learning to move GUI components in grid space.')
     Sharkinfo4= Text(Point(520, 500), 'There are Run, Move, Reset and Quit button, Run will continues moving until all fish get eaten.')
     Sharkinfo.draw(win)
     Sharkinfo2.draw(win)
     Sharkinfo3.draw(win)
     Sharkinfo4.draw(win)
        
     while True:
         m = win.getMouse()
         if P1.isClicked(m):
             P1main()
         if P2.isClicked(m):
             P2main()
         if P3.isClicked(m):
             P3main()
         if Image.isClicked(m):
             Imagemain()
         if Shark.isClicked(m):
             Sharkmain()
         if Q.isClicked(m):
             break

     win.close()

if __name__ == "__main__":
    main()
